<style type="text/css">
	body {
		margin: 0;
		padding: 0;
		clear: both;
	}

	#output {
		padding: 10px;
		font-size: 20px;
	}

	#output pre {
		margin: 0;
		margin-bottom: 0.1em;
	}

	#output hr {
		margin-top: 5px;
		margin-bottom: 10px;
	}
</style>

<div id="output">
	
</div>