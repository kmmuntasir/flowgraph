
<!-- jQuery CDN - Slim version (=without AJAX) -->
<script src="<?php echo $fullpath; ?>assets/jquery/3.3.1/jquery.min.js"></script>
<!-- Popper.JS -->
<script src="<?php echo $fullpath; ?>assets/popper/1.14.0/popper.min.js"></script>
<!-- Bootstrap JS -->
<script src="<?php echo $fullpath; ?>assets/bootstrap/4.1.3/js/bootstrap.min.js"></script>
<!-- jQuery Custom Scroller CDN -->
<script src="<?php echo $fullpath; ?>assets/malihu-custom-scrollbar-plugin/3.1.5/jquery.mCustomScrollbar.concat.min.js"></script>


<!-- DataTables Js -->
<script src="<?php echo $fullpath; ?>assets/DataTables/datatables.min.js"></script>
<script src="<?php echo $fullpath; ?>assets/DataTables/Buttons-1.5.1/js/dataTables.buttons.min.js"></script>
<!--<script src="<?php echo $fullpath; ?>assets/DataTables/Buttons-1.5.1/js/buttons.flash.min.js"></script>-->
<script src="<?php echo $fullpath; ?>assets/DataTables/Buttons-1.5.1/js/jszip.min.js"></script>
<script src="<?php echo $fullpath; ?>assets/DataTables/Buttons-1.5.1/js/buttons.html5.min.js"></script>
<script src="<?php echo $fullpath; ?>assets/DataTables/Buttons-1.5.1/js/buttons.print.min.js"></script>


<!-- jQuery-DateFormat JS -->
<script src="<?php echo $fullpath; ?>assets/jquery-dateFormat/jquery-dateformat.min.js"></script>

<!-- jQuery Datepicker JS -->
<script src="<?php echo $fullpath; ?>assets/jQuery-ui/jquery-ui.min.js"></script>

<!-- jQuery Timepicker JS -->
<script src="<?php echo $fullpath; ?>assets/jquery_timepicker/jquery.timepicker.min.js"></script>



<!-- Optima-edu custom js -->
<script src="<?php echo $fullpath; ?>js/optima-edu.js"></script>
<script src="<?php echo $fullpath; ?>js/optima-edu-datatables.js"></script>

<!-- Page Depended JS -->
<script src="<?php echo $fullpath.'js/page_js/'.$page.'.js'; ?>"></script>	

