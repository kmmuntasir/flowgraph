<h1><?php echo $page_title; ?></h1>
